Kerio Migrator v1.1.52
======================

This package contains the Git patch for the selectable IMAP-folder migration
feature added after v1.1.51.

Apply the patch from the Kerio Migrator repository root with:
  git am kerio-migrator-v1.1.52-from-v1.1.51.patch

The patch updates imap_migrator.py and build.bat. It adds asynchronous per-
account folder loading, folder checkboxes and select-all controls, selection
filtering for analysis/count/size/migration/checkpoints, IMAP delimiter
normalization, and folder/LIST diagnostics.

Validation performed before packaging:
  python3 -m py_compile imap_migrator.py
  git diff --check

A Windows EXE must be built on Windows by running build.bat. The synchronized
application version is v1.1.52.
